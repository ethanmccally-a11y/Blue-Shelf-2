import { Navigation } from "@/components/navigation"
import { Hero } from "@/components/hero"
import { PlatformStrip } from "@/components/platform-strip"
import { Portfolio } from "@/components/portfolio"
import { BeforeAfter } from "@/components/before-after"
import { Consistency } from "@/components/consistency"
import { ContentScore } from "@/components/content-score"
import { Services } from "@/components/services"
import { Pricing } from "@/components/pricing"
import { Process } from "@/components/process"
import { FAQ } from "@/components/faq"
import { ContactCTA } from "@/components/contact-cta"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Navigation />
      <Hero />
      <PlatformStrip />
      <Portfolio />
      <BeforeAfter />
      <Consistency />
      <ContentScore />
      <Services />
      <Pricing />
      <Process />
      <FAQ />
      <ContactCTA />
      <Footer />
    </main>
  )
}
