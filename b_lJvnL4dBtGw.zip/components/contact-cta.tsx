"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Mail, Phone, ArrowRight } from "lucide-react"

export function ContactCTA() {
  const [formData, setFormData] = useState({
    name: "",
    company: "",
    email: "",
    phone: "",
    skus: "",
    details: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Form submitted:", formData)
  }

  return (
    <section id="contact" className="bg-[#0f0f1a] py-24">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Left content */}
          <div>
            <h2 className="text-4xl lg:text-5xl font-black text-white">
              Get Retail-Ready<br />Content.
            </h2>
            <p className="text-white/60 text-lg mt-6 max-w-md">
              Tell us about your brand and we&apos;ll send you a clear, itemized quote within 24 hours.
            </p>
            
            <div className="mt-12 space-y-6">
              <a 
                href="mailto:sales@blue-shelf.com"
                className="flex items-center gap-4 text-white/80 hover:text-white transition-colors"
              >
                <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center">
                  <Mail className="w-5 h-5" />
                </div>
                <span>sales@blue-shelf.com</span>
              </a>
              
              <a 
                href="tel:+14694062607"
                className="flex items-center gap-4 text-white/80 hover:text-white transition-colors"
              >
                <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center">
                  <Phone className="w-5 h-5" />
                </div>
                <span>(469) 406-2607</span>
              </a>
            </div>
          </div>

          {/* Right content - Form */}
          <div className="bg-transparent">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <Input
                  placeholder="Your name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="bg-transparent border-white/20 text-white placeholder:text-white/40 rounded-xl h-14"
                />
                <Input
                  placeholder="Brand / Company"
                  value={formData.company}
                  onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                  className="bg-transparent border-white/20 text-white placeholder:text-white/40 rounded-xl h-14"
                />
              </div>
              
              <div className="grid sm:grid-cols-2 gap-4">
                <Input
                  type="email"
                  placeholder="Email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="bg-transparent border-white/20 text-white placeholder:text-white/40 rounded-xl h-14"
                />
                <Input
                  type="tel"
                  placeholder="Phone"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="bg-transparent border-white/20 text-white placeholder:text-white/40 rounded-xl h-14"
                />
              </div>
              
              <Input
                placeholder="Number of SKUs"
                value={formData.skus}
                onChange={(e) => setFormData({ ...formData, skus: e.target.value })}
                className="bg-transparent border-white/20 text-white placeholder:text-white/40 rounded-xl h-14"
              />
              
              <Textarea
                placeholder="What do you need? Image types, platforms, timeline..."
                value={formData.details}
                onChange={(e) => setFormData({ ...formData, details: e.target.value })}
                className="bg-transparent border-white/20 text-white placeholder:text-white/40 rounded-xl min-h-[120px] resize-none"
              />
              
              <Button 
                type="submit"
                size="lg"
                className="w-full bg-[#4d7cfe] hover:bg-[#3d6cee] text-white rounded-full py-7 text-base font-semibold"
              >
                Request a Quote
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              
              <p className="text-center text-white/40 text-sm">
                Response within 24 hours.
              </p>
            </form>
          </div>
        </div>
      </div>
    </section>
  )
}
