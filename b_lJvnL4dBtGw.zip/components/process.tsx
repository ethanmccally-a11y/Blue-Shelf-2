import { Package, Camera, Eye, Download, Clock, Zap } from "lucide-react"

const steps = [
  {
    number: "01",
    icon: Package,
    title: "Send Product",
    description: "Ship your product to our studio. We handle intake and prep.",
  },
  {
    number: "02",
    icon: Camera,
    title: "We Create Content",
    description: "Professional photography and content production — all formats.",
  },
  {
    number: "03",
    icon: Eye,
    title: "Review Proofs",
    description: "You review every image before we finalize. Revisions included.",
  },
  {
    number: "04",
    icon: Download,
    title: "Final Delivery",
    description: "Upload-ready files in every format. Ready for your listing.",
  },
]

export function Process() {
  return (
    <section id="process" className="bg-white py-24">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-20">
          <span className="text-[#4d7cfe] text-sm font-semibold tracking-[0.2em] uppercase block mb-4">
            How It Works
          </span>
          <h2 className="text-4xl lg:text-5xl font-black text-gray-900">
            Ship it. We&apos;ll handle<br />the rest.
          </h2>
        </div>

        {/* Steps Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-12 mb-20">
          {steps.map((step) => (
            <div key={step.number} className="flex flex-col items-center text-center">
              {/* Icon Box */}
              <div className="w-20 h-20 rounded-2xl border border-gray-200 flex items-center justify-center mb-6">
                <step.icon className="w-8 h-8 text-[#4d7cfe]" strokeWidth={1.5} />
              </div>
              
              {/* Step Number */}
              <span className="text-gray-400 text-xs font-medium tracking-[0.15em] uppercase mb-2">
                Step {step.number}
              </span>
              
              {/* Title */}
              <h3 className="text-lg font-bold text-gray-900 mb-3">
                {step.title}
              </h3>
              
              {/* Description */}
              <p className="text-gray-500 text-sm leading-relaxed max-w-[200px]">
                {step.description}
              </p>
            </div>
          ))}
        </div>

        {/* Turnaround Cards */}
        <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          {/* Standard */}
          <div className="bg-gray-50 rounded-2xl p-6 flex items-center gap-5">
            <div className="w-14 h-14 rounded-full bg-white border border-gray-200 flex items-center justify-center flex-shrink-0">
              <Clock className="w-6 h-6 text-gray-400" strokeWidth={1.5} />
            </div>
            <div>
              <span className="text-gray-400 text-xs font-semibold tracking-[0.15em] uppercase block mb-1">
                Standard
              </span>
              <span className="text-xl font-black text-gray-900">
                10–12 Business Days
              </span>
            </div>
          </div>
          
          {/* Expedited */}
          <div className="bg-amber-50/50 rounded-2xl p-6 flex items-center gap-5">
            <div className="w-14 h-14 rounded-full bg-amber-100 flex items-center justify-center flex-shrink-0">
              <Zap className="w-6 h-6 text-amber-500" strokeWidth={1.5} />
            </div>
            <div>
              <span className="text-amber-500 text-xs font-semibold tracking-[0.15em] uppercase block mb-1">
                Expedited
              </span>
              <span className="text-xl font-black text-gray-900">
                3–5 Business Days
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
