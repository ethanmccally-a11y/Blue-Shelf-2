"use client"

export function PlatformStrip() {
  const platforms = [
    { name: "Amazon", color: "text-[#FF9900]" },
    { name: "Target", color: "text-[#CC0000]" },
    { name: "Shopify", color: "text-[#96bf48]" },
    { name: "Instacart", color: "text-[#43b02a]" },
    { name: "Sam's Club", color: "text-[#0067a0]" },
    { name: "Walmart", color: "text-[#0071ce]" },
  ]

  // Double the array for seamless infinite scroll
  const doubledPlatforms = [...platforms, ...platforms]

  return (
    <section className="bg-[#0f0f1a] border-t border-white/10 py-12 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <h3 className="text-center text-white font-bold text-xl mb-8">
          Built for Ecommerce. Designed to Convert.
        </h3>
        
        <div className="relative">
          {/* Gradient fades on edges */}
          <div className="absolute left-0 top-0 bottom-0 w-20 bg-gradient-to-r from-[#0f0f1a] to-transparent z-10 pointer-events-none" />
          <div className="absolute right-0 top-0 bottom-0 w-20 bg-gradient-to-l from-[#0f0f1a] to-transparent z-10 pointer-events-none" />
          
          {/* Scrolling container */}
          <div className="flex animate-scroll">
            {doubledPlatforms.map((platform, index) => (
              <div
                key={`${platform.name}-${index}`}
                className="bg-white rounded-full px-6 py-3 flex items-center justify-center min-w-[140px] mx-2 flex-shrink-0"
              >
                <span className={`font-semibold text-sm ${platform.color}`}>
                  {platform.name}
                </span>
              </div>
            ))}
          </div>
        </div>
        
        <p className="text-center text-white/40 text-xs mt-6">
          Platform logos are used for illustrative purposes only. Blue Shelf is not affiliated with or endorsed by these companies.
        </p>
      </div>
    </section>
  )
}
