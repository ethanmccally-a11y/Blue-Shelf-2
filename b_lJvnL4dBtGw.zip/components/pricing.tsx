const pricingItems = [
  {
    title: "White Background",
    description: "Pure white, center-weighted. Retailer-spec ready.",
    price: "$75+",
    unit: "per image",
  },
  {
    title: "Styled Studio",
    description: "Brand-aligned studio setup with art direction.",
    price: "$175+",
    unit: "per image",
  },
  {
    title: "Lifestyle",
    description: "In-use, editorial-quality contextual photography.",
    price: "$200+",
    unit: "per image",
  },
  {
    title: "Infographics",
    description: "Feature callouts and benefit graphics. Built to convert.",
    price: "$100+",
    unit: "per image",
  },
  {
    title: "In-Package Shots",
    description: "Macro detail shots revealing label, texture, and build quality.",
    price: "$75+",
    unit: "per image",
  },
  {
    title: "Compliance Review",
    description: "Full retailer spec audit and remediation. Rejection-proof.",
    price: "$300+",
    unit: "per project",
  },
]

export function Pricing() {
  return (
    <section id="pricing" className="bg-gray-50 py-24">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <span className="text-[#4d7cfe] text-sm font-semibold tracking-[0.2em] uppercase">
            Pricing
          </span>
          <h2 className="text-4xl lg:text-5xl font-black text-gray-900 mt-4">
            Transparent pricing.
          </h2>
          <p className="text-gray-500 text-lg mt-4">
            Starting points. Final pricing depends on scope and complexity.
          </p>
          <p className="text-gray-700 mt-4 text-lg">
            Most projects range from <span className="font-bold">$1,500–$6,000+</span> depending on scope.
          </p>
        </div>

        {/* Pricing grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {pricingItems.map((item) => (
            <div
              key={item.title}
              className="bg-white rounded-2xl p-6 border border-gray-100"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-gray-900">{item.title}</h3>
                  <p className="text-gray-500 text-sm mt-2 leading-relaxed">{item.description}</p>
                </div>
                <div className="text-right ml-4">
                  <span className="text-xs text-gray-400 tracking-widest uppercase">Starting at</span>
                  <div className="text-3xl font-black text-[#4d7cfe]">{item.price}</div>
                  <span className="text-xs text-gray-400">{item.unit}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Disclaimer */}
        <div className="bg-white rounded-2xl p-6 border border-gray-100">
          <p className="text-gray-500 text-sm">
            <span className="font-semibold text-gray-900">Additional costs</span> may apply for props, specialty ingredients, models, advanced styling, expedited timelines, and revisions. All clearly outlined at quoting.
          </p>
        </div>
      </div>
    </section>
  )
}
