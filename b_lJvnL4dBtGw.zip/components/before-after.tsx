import Image from "next/image"
import { X, Check } from "lucide-react"

const unoptimizedIssues = [
  { label: "Low Resolution", position: "top-[15%] right-[10%]" },
  { label: "Wrinkled Packaging", position: "top-[35%] left-[5%]" },
  { label: "Off-Center Alignment", position: "top-[55%] right-[5%]" },
  { label: "Not Pure White Background", position: "bottom-[25%] left-[8%]" },
  { label: "Inconsistent Lighting", position: "bottom-[10%] right-[12%]" },
]

const optimizedFeatures = [
  { label: "High Resolution", position: "top-[15%] right-[10%]" },
  { label: "True White Background", position: "top-[35%] left-[5%]" },
  { label: "Perfect Alignment", position: "top-[55%] right-[5%]" },
  { label: "Clean Lighting", position: "bottom-[25%] left-[8%]" },
]

export function BeforeAfter() {
  return (
    <section id="before-after" className="bg-white py-24">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-black text-gray-900 max-w-3xl mx-auto text-balance">
            Shoppers don&apos;t read listings — they scan. Poor visuals kill trust and conversion.
          </h2>
          <p className="text-gray-500 text-lg mt-6 max-w-2xl mx-auto">
            Small inconsistencies in your images can significantly impact performance. We fix that.
          </p>
        </div>

        {/* Comparison */}
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Unoptimized */}
          <div className="relative">
            <div className="relative bg-gray-100 rounded-2xl overflow-hidden shadow-lg">
              {/* Label */}
              <div className="absolute top-4 left-4 z-20">
                <span className="inline-flex items-center gap-2 bg-red-500/90 backdrop-blur-sm text-white text-xs font-semibold px-4 py-2 rounded-full">
                  <X className="w-3 h-3" />
                  Unoptimized Listing
                </span>
              </div>
              
              {/* Image container */}
              <div className="relative aspect-square p-6">
                <Image
                  src="/images/comparison-unoptimized.jpg"
                  alt="Unoptimized product listing with issues"
                  fill
                  className="object-contain"
                />
                
                {/* Issue callouts */}
                {unoptimizedIssues.map((issue, index) => (
                  <div
                    key={index}
                    className={`absolute ${issue.position} z-10 hidden md:block`}
                  >
                    <div className="relative">
                      <div className="bg-red-500/90 backdrop-blur-sm text-white text-[10px] font-medium px-2 py-1 rounded whitespace-nowrap shadow-lg">
                        {issue.label}
                      </div>
                      <div className="absolute top-1/2 -translate-y-1/2 -right-3 w-3 h-px bg-red-500" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Mobile list of issues */}
            <ul className="mt-6 space-y-2 md:hidden">
              {unoptimizedIssues.map((issue, index) => (
                <li key={index} className="flex items-center gap-2 text-gray-600 text-sm">
                  <X className="w-3 h-3 text-red-500 flex-shrink-0" />
                  {issue.label}
                </li>
              ))}
            </ul>
          </div>

          {/* Optimized */}
          <div className="relative">
            <div className="relative bg-white rounded-2xl overflow-hidden shadow-lg border border-gray-100">
              {/* Label */}
              <div className="absolute top-4 left-4 z-20">
                <span className="inline-flex items-center gap-2 bg-[#4d7cfe]/90 backdrop-blur-sm text-white text-xs font-semibold px-4 py-2 rounded-full">
                  <Check className="w-3 h-3" />
                  Blue Shelf Optimized
                </span>
              </div>
              
              {/* Content Score badge */}
              <div className="absolute top-4 right-4 z-20 bg-white/90 backdrop-blur-sm rounded-lg px-3 py-1.5 shadow-md border border-gray-100">
                <div className="text-[8px] text-gray-400 tracking-widest font-medium">CONTENT SCORE</div>
                <div className="text-lg font-black text-green-500">100/100</div>
              </div>
              
              {/* Image container */}
              <div className="relative aspect-square p-6">
                <Image
                  src="/images/comparison-optimized.jpg"
                  alt="Blue Shelf optimized product listing"
                  fill
                  className="object-contain"
                />
                
                {/* Feature callouts */}
                {optimizedFeatures.map((feature, index) => (
                  <div
                    key={index}
                    className={`absolute ${feature.position} z-10 hidden md:block`}
                  >
                    <div className="relative">
                      <div className="bg-[#4d7cfe]/90 backdrop-blur-sm text-white text-[10px] font-medium px-2 py-1 rounded whitespace-nowrap shadow-lg">
                        {feature.label}
                      </div>
                      <div className="absolute top-1/2 -translate-y-1/2 -left-3 w-3 h-px bg-[#4d7cfe]" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Mobile list of features */}
            <ul className="mt-6 space-y-2 md:hidden">
              {optimizedFeatures.map((feature, index) => (
                <li key={index} className="flex items-center gap-2 text-gray-600 text-sm">
                  <Check className="w-3 h-3 text-[#4d7cfe] flex-shrink-0" />
                  {feature.label}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}
