"use client"

import { useState } from "react"
import { ChevronDown } from "lucide-react"
import { cn } from "@/lib/utils"

const faqs = [
  {
    question: "What is content score and why does it matter?",
    answer: (
      <>
        <p className="mb-3">
          Retailers like Walmart use internal scoring systems (often referred to as Listing Quality or Content Score) to evaluate how complete and optimized a product listing is.
        </p>
        <p className="mb-2">This includes:</p>
        <ul className="list-disc list-inside mb-3 space-y-1 text-gray-600">
          <li>Image quality and consistency</li>
          <li>Number of images provided</li>
          <li>Clarity of product information</li>
          <li>Overall completeness of the listing</li>
        </ul>
        <p className="mb-2">Listings with higher scores are more likely to:</p>
        <ul className="list-disc list-inside space-y-1 text-gray-600">
          <li>Rank higher in search results</li>
          <li>Win more Buy Box placements</li>
          <li>Convert at a higher rate</li>
        </ul>
      </>
    ),
  },
  {
    question: "Why does content quality matter so much?",
    answer: (
      <>
        <p className="mb-3">
          On platforms like Walmart and Amazon, your images are one of the biggest drivers of performance. Shoppers make decisions in seconds, and listings with clear, high-quality visuals consistently outperform those without.
        </p>
        <p>
          High-quality product imagery has been shown to increase conversion rates by <strong>20–30%</strong> or more, while poor or inconsistent visuals can reduce trust and click-through.
        </p>
      </>
    ),
  },
  {
    question: "When does a project start?",
    answer: "Projects begin once your product is delivered to our studio. This allows us to move directly into production without delays.",
  },
  {
    question: "How long does a project take?",
    answer: (
      <>
        <p>
          Standard turnaround is <strong>10–12 business days</strong> from product arrival.
        </p>
        <p>
          Expedited projects are completed in <strong>3–5 business days</strong>.
        </p>
      </>
    ),
  },
  {
    question: "What if I'm not sure what my listing needs?",
    answer: (
      <>
        <p className="mb-3">
          {"That's completely normal. Most brands don't know exactly what's missing — they just know performance could be better."}
        </p>
        <p>
          We guide you through a structured shot list and work with you to define exactly what your listing needs — from product shots to infographics — ensuring everything is aligned and built to perform.
        </p>
      </>
    ),
  },
  {
    question: "Can you match our brand style?",
    answer: (
      <>
        <p className="mb-3">Absolutely. We build every project around your brand.</p>
        <p>
          We align on tone, positioning, and visual direction upfront, then structure the content so it feels consistent with your brand while still meeting platform expectations and driving performance.
        </p>
      </>
    ),
  },
  {
    question: "Do you offer expedited options?",
    answer: (
      <>
        Yes. Expedited projects are completed in <strong>3–5 business days</strong> once your product is received.
      </>
    ),
  },
]

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0)

  return (
    <section className="py-24 bg-gray-50">
      <div className="max-w-3xl mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-12">
          <p className="text-sm font-semibold text-blue-600 tracking-widest uppercase mb-3">
            FAQ
          </p>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900">
            What to Expect
          </h2>
        </div>

        {/* FAQ List */}
        <div className="space-y-4">
          {faqs.map((faq, i) => (
            <div 
              key={i}
              className="bg-white rounded-xl border border-gray-200 overflow-hidden"
            >
              <button
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
                className="w-full flex items-center justify-between p-6 text-left"
              >
                <span className="font-semibold text-gray-900 pr-4">{faq.question}</span>
                <ChevronDown 
                  className={cn(
                    "w-5 h-5 text-gray-400 flex-shrink-0 transition-transform duration-200",
                    openIndex === i && "rotate-180"
                  )} 
                />
              </button>
              <div 
                className={cn(
                  "overflow-hidden transition-all duration-200",
                  openIndex === i ? "max-h-[500px]" : "max-h-0"
                )}
              >
                <div className="px-6 pb-6 text-gray-600">
                  {faq.answer}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
