import Image from "next/image"

const footerLinks = [
  { label: "Work", href: "#portfolio" },
  { label: "Services", href: "#services" },
  { label: "Pricing", href: "#pricing" },
  { label: "Process", href: "#process" },
  { label: "Contact", href: "#contact" },
]

export function Footer() {
  return (
    <footer className="bg-gray-50 border-t border-gray-200 py-12">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-8">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <Image
              src="/images/logo.png"
              alt="Blue Shelf"
              width={32}
              height={32}
              className="w-8 h-8"
            />
            <span className="text-lg font-bold text-gray-900">Blue Shelf</span>
          </div>

          {/* Navigation */}
          <nav className="flex flex-wrap justify-center gap-8">
            {footerLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-gray-500 hover:text-gray-900 text-sm font-medium transition-colors"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Contact info */}
          <div className="text-right text-sm text-gray-500">
            <div>sales@blue-shelf.com</div>
            <div>(469) 406-2607</div>
          </div>
        </div>
      </div>
    </footer>
  )
}
