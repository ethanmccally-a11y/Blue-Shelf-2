import Image from "next/image"

const services = [
  {
    number: "01",
    title: "White Background",
    description: "Pure white studio shots. Retailer-compliant. Conversion-optimized.",
    image: "/images/service-white-bg.jpg",
  },
  {
    number: "02",
    title: "Styled Studio",
    description: "Brand-aligned studio setups with props, lighting, and editorial feel.",
    image: "/images/service-styled-studio.jpg",
  },
  {
    number: "03",
    title: "Lifestyle",
    description: "In-use, in-context photography that shows your product in the real world.",
    image: "/images/service-lifestyle.jpg",
  },
  {
    number: "04",
    title: "Infographics",
    description: "Benefit callouts, ingredient highlights, and feature graphics built to convert.",
    image: "/images/service-infographic.jpg",
  },
]

export function Services() {
  return (
    <section id="services" className="bg-white py-24">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="mb-16">
          <span className="text-[#4d7cfe] text-sm font-semibold tracking-[0.2em] uppercase">
            Services
          </span>
          <h2 className="text-4xl lg:text-5xl font-black text-gray-900 mt-4 max-w-lg">
            Everything your listing needs.
          </h2>
        </div>

        {/* Services grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service) => (
            <div
              key={service.number}
              className="group bg-gray-50 rounded-2xl overflow-hidden border border-gray-100 hover:shadow-lg transition-shadow"
            >
              {/* Image */}
              <div className="relative aspect-square bg-white">
                <Image
                  src={service.image}
                  alt={service.title}
                  fill
                  className="object-contain p-6"
                />
              </div>
              
              {/* Content */}
              <div className="p-6">
                <span className="text-gray-400 text-sm font-medium">{service.number}</span>
                <h3 className="text-xl font-bold text-gray-900 mt-1">{service.title}</h3>
                <p className="text-gray-500 mt-2 text-sm leading-relaxed">{service.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
