"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import { ArrowRight } from "lucide-react"

const carouselImages = [
  { src: "/images/hero-product.jpg", alt: "Sustainables Fiber Plates", label: "ECO-FRIENDLY" },
  { src: "/images/lifestyle-bbq.jpg", alt: "BBQ Lifestyle Shot", label: "LIFESTYLE" },
  { src: "/images/lifestyle-burger.jpg", alt: "Styled Studio Shot", label: "STYLED STUDIO" },
  { src: "/images/product-package.jpg", alt: "Package Display", label: "PACKAGING" },
  { src: "/images/lifestyle-combined.jpg", alt: "Combined Lifestyle", label: "IN-USE" },
  { src: "/images/infographic.jpg", alt: "Product Infographic", label: "INFOGRAPHIC" },
]

export function Hero() {
  const [currentIndex, setCurrentIndex] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % carouselImages.length)
    }, 3500)
    return () => clearInterval(interval)
  }, [])

  return (
    <section id="hero" className="relative bg-[#0f0f1a] min-h-screen">
      <div className="max-w-7xl mx-auto px-6 py-20 lg:py-32">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left content */}
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 bg-white/10 rounded-full px-4 py-2">
              <div className="w-2 h-2 bg-blue-500 rounded-full" />
              <span className="text-white/80 text-sm font-medium tracking-wide">CPG PRODUCT PHOTOGRAPHY</span>
            </div>
            
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-black text-white leading-[1.1] tracking-tight">
              Win on the<br />
              <span className="text-[#4d7cfe]">Digital Shelf.</span>
            </h1>
            
            <p className="text-lg text-white/60 max-w-md leading-relaxed">
              High-performing product content designed to increase conversion and elevate your listings.
            </p>
            
            <div className="flex items-center gap-4 pt-2">
              <Button 
                size="lg" 
                className="bg-[#4d7cfe] hover:bg-[#3d6cee] text-white rounded-full px-8 py-6 text-base font-semibold"
                asChild
              >
                <a href="#contact">
                  Request a Quote
                  <ArrowRight className="ml-2 h-4 w-4" />
                </a>
              </Button>
              <Button 
                variant="ghost" 
                size="lg"
                className="text-white hover:text-white hover:bg-white/10 rounded-full px-6 py-6 text-base font-medium"
                asChild
              >
                <a href="#portfolio">
                  View Our Work
                  <ArrowRight className="ml-2 h-4 w-4" />
                </a>
              </Button>
            </div>
          </div>

          {/* Right content - Product carousel */}
          <div className="relative flex items-center justify-center">
            <div className="relative bg-white rounded-3xl p-6 shadow-2xl w-full max-w-md">
              {/* Content Score Badge */}
              <div className="absolute -top-4 -right-4 bg-white rounded-xl px-4 py-3 shadow-lg border border-gray-100 z-10">
                <div className="text-[10px] text-gray-400 tracking-widest font-medium">CONTENT SCORE</div>
                <div className="text-2xl font-black text-[#4d7cfe]">100/100</div>
              </div>

              {/* Product image */}
              <div className="relative aspect-square w-full flex items-center justify-center bg-white rounded-2xl overflow-hidden">
                {carouselImages.map((image, index) => (
                  <div
                    key={image.src}
                    className={`absolute inset-0 flex items-center justify-center transition-opacity duration-700 ease-in-out ${
                      index === currentIndex ? "opacity-100" : "opacity-0"
                    }`}
                  >
                    <Image
                      src={image.src}
                      alt={image.alt}
                      width={400}
                      height={400}
                      className="w-full h-full object-contain p-4"
                      priority={index === 0}
                    />
                  </div>
                ))}
              </div>

              {/* Category label */}
              <div className="absolute bottom-8 left-8">
                <span className="bg-gray-800 text-white text-xs font-medium px-4 py-2 rounded-full tracking-wide">
                  {carouselImages[currentIndex].label}
                </span>
              </div>

              {/* Carousel indicators */}
              <div className="flex justify-center gap-2 mt-4">
                {carouselImages.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentIndex(index)}
                    className={`w-2 h-2 rounded-full transition-all duration-300 ${
                      index === currentIndex ? "bg-[#4d7cfe] w-6" : "bg-gray-300"
                    }`}
                    aria-label={`Go to slide ${index + 1}`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
